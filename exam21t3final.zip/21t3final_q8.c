#include <stdio.h>

// print the location of a specified byte sequence in a file
// the first command line argument is a filname
// other command line arguments are integers specifying a byte sequence
// the first position the byte sequence occurs in the file is printed

int main(int argc, char *argv[]) {

    // PUT YOUR CODE HERE

    return 0;
}
