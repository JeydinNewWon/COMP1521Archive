char *my_name(void);
