#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>

#define MAKEFILE_NAME "MyMakefile"
#define MAX_LINE_LEN  255

int main(int argc, char *argv[]) {

    // PUT YOUR CODE HERE

    return 0;
}
