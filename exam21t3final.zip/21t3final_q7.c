#include <stdio.h>

// copy file specified as command line argument 1 to
// file specified as command line argument 2
// convert UTF8 to ASCII by replacing multibyte UTF8 characters with '?'

int main(int argc, char *argv[]) {

    // PUT YOUR CODE HERE

    return 0;
}
