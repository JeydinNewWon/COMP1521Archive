#include "bar.h"

char *my_name(void) {
    return "bar";
}
