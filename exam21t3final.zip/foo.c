#include <stdio.h>
#include "bar.h"

int main(void) {
    printf("my name is %s\n", my_name());
}
